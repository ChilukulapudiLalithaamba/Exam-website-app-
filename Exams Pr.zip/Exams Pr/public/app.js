document.addEventListener('DOMContentLoaded', () => {
  // --- PAGE ELEMENTS ---
  const loginPage = document.getElementById('login-page');
  const examPage = document.getElementById('exam-page');
  const resultsPage = document.getElementById('results-page');

  const loginForm = document.getElementById('login-form');
  const usernameInput = document.getElementById('username');
  const passwordInput = document.getElementById('password'); // added

  const partTitle = document.getElementById('part-title');
  const timerEl = document.getElementById('timer');
  const questionText = document.getElementById('question-text');
  const optionsContainer = document.getElementById('options-container');
  const questionCounter = document.getElementById('question-counter');
  const prevBtn = document.getElementById('prev-btn');
  const nextBtn = document.getElementById('next-btn');
  const submitPartBtn = document.getElementById('submit-part-btn');

  const cameraPlaceholder = document.getElementById('camera-placeholder');
  const videoFeed = document.getElementById('camera-feed');
  const logoutBtn = document.getElementById('logout-btn');

  const finalScoreDisplay = document.getElementById('final-score');

  // --- APP STATE VARIABLES ---
  let allQuestions = [];
  let currentPartIndex = 0;
  let currentQuestionIndex = 0;
  let userAnswers = {};
  let scores = [];
  let timerInterval;
  let cameraStarted = false;
  let examStartTime = null;
  let studentName = '';

  const PART_DURATION = 30 * 60;

  // --- INIT ---
  const init = async () => {
    loginForm.addEventListener('submit', handleLogin);
    nextBtn.addEventListener('click', showNextQuestion);
    prevBtn.addEventListener('click', showPreviousQuestion);
    submitPartBtn.addEventListener('click', () => {
      if (confirm('Are you sure you want to submit this part?')) {
        handleSubmitPart();
      }
    });
    logoutBtn.addEventListener('click', handleLogout);
    optionsContainer.addEventListener('change', handleAnswerSelection);

    try {
      const res = await fetch('/api/questions');
      if (!res.ok) throw new Error('Failed to fetch questions');
      const data = await res.json();
      allQuestions = data.parts;
    } catch (err) {
      alert('Error loading questions.');
      console.error(err);
    }

    await startCamera();
  };

  // --- CAMERA ---
  async function startCamera() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      videoFeed.srcObject = stream;
      cameraPlaceholder.classList.add('hidden');
      videoFeed.classList.remove('hidden');
      cameraStarted = true;
    } catch (err) {
      cameraStarted = false;
      cameraPlaceholder.innerHTML = `<p>Camera access was denied. Please allow access to begin.</p>`;
      console.error("Camera error:", err);
    }
  }

  function stopCamera() {
    if (videoFeed.srcObject) {
      videoFeed.srcObject.getTracks().forEach(track => track.stop());
      videoFeed.srcObject = null;
    }
    videoFeed.classList.add('hidden');
    cameraPlaceholder.classList.remove('hidden');
    cameraPlaceholder.innerHTML = `<p>Camera is off</p>`;
  }

  // --- LOGIN (updated to check role) ---
  async function handleLogin(e) {
    e.preventDefault();
    const username = usernameInput.value.trim();
    const password = passwordInput.value.trim();

    if (!username || !password) {
      return alert('Please enter username and password');
    }

    const res = await fetch("/api/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password })
    });

    const data = await res.json();
    if (data.success) {
      localStorage.setItem("username", data.username);
      localStorage.setItem("role", data.role);

      if (data.role === "admin") {
        window.location.href = "admin.html";
        return;
      }

      // student login
      if (!cameraStarted) {
        return alert('Camera access is required to start the exam.');
      }

      studentName = data.username;
      loginPage.classList.add('hidden');
      examPage.classList.remove('hidden');
      examStartTime = new Date();
      startPart(0);
    } else {
      alert(data.message);
    }
  }

  function handleLogout() {
    resultsPage.classList.add('hidden');
    loginPage.classList.remove('hidden');
    loginForm.reset();
    currentPartIndex = 0;
    currentQuestionIndex = 0;
    userAnswers = {};
    scores = [];
    stopCamera();
    clearInterval(timerInterval);
    cameraStarted = false;
  }

  // --- PART CONTROL ---
  function startPart(index) {
    currentPartIndex = index;
    currentQuestionIndex = 0;
    partTitle.textContent = `Part ${index + 1}`;
    displayQuestion(currentQuestionIndex);
    startTimer();
  }

  function displayQuestion(index) {
    const part = allQuestions[currentPartIndex];
    const question = part[index];

    questionText.textContent = `${index + 1}. ${question.question}`;
    optionsContainer.innerHTML = '';

    question.options.forEach((option, optIdx) => {
      const optionId = `q${index}_opt${optIdx}`;
      const label = document.createElement('label');
      label.className = 'option';
      label.htmlFor = optionId;

      const radio = document.createElement('input');
      radio.type = 'radio';
      radio.name = `question-${index}`;
      radio.id = optionId;
      radio.value = option;

      const key = `${currentPartIndex}-${index}`;
      if (userAnswers[key] === option) {
        radio.checked = true;
        label.classList.add('selected');
      }

      label.appendChild(radio);
      label.append(` ${option}`);
      optionsContainer.appendChild(label);
    });

    updateNavigation();
  }

  function updateNavigation() {
    const total = allQuestions[currentPartIndex].length;
    questionCounter.textContent = `Question ${currentQuestionIndex + 1} / ${total}`;
    prevBtn.disabled = currentQuestionIndex === 0;
    nextBtn.disabled = currentQuestionIndex === total - 1;
  }

  function showNextQuestion() {
    if (currentQuestionIndex < allQuestions[currentPartIndex].length - 1) {
      currentQuestionIndex++;
      displayQuestion(currentQuestionIndex);
    }
  }

  function showPreviousQuestion() {
    if (currentQuestionIndex > 0) {
      currentQuestionIndex--;
      displayQuestion(currentQuestionIndex);
    }
  }

  // --- ANSWERS ---
  function handleAnswerSelection(e) {
    if (e.target.type === 'radio') {
      const value = e.target.value;
      const key = `${currentPartIndex}-${currentQuestionIndex}`;
      userAnswers[key] = value;

      document.querySelectorAll('.option').forEach(label => label.classList.remove('selected'));
      e.target.parentElement.classList.add('selected');
    }
  }

  // --- TIMER ---
  function startTimer() {
    let timeLeft = PART_DURATION;
    timerEl.textContent = formatTime(timeLeft);
    clearInterval(timerInterval);

    timerInterval = setInterval(() => {
      timeLeft--;
      timerEl.textContent = formatTime(timeLeft);
      if (timeLeft <= 0) {
        clearInterval(timerInterval);
        alert("Time's up!");
        handleSubmitPart();
      }
    }, 1000);
  }

  function formatTime(seconds) {
    const m = Math.floor(seconds / 60).toString().padStart(2, '0');
    const s = (seconds % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  }

  // --- SUBMIT ---
  function handleSubmitPart() {
    clearInterval(timerInterval);
    calculateScore();

    if (currentPartIndex < allQuestions.length - 1) {
      startPart(currentPartIndex + 1);
    } else {
      showFinalResults();
    }
  }

  function calculateScore() {
    let score = 0;
    const part = allQuestions[currentPartIndex];
    part.forEach((q, idx) => {
      const key = `${currentPartIndex}-${idx}`;
      if (userAnswers[key] === q.answer) score++;
    });
    scores[currentPartIndex] = score;
  }

  function showFinalResults() {
    examPage.classList.add('hidden');
    resultsPage.classList.remove('hidden');

    const totalScore = scores.reduce((a, b) => a + (b || 0), 0);
    const totalQuestions = allQuestions.reduce((acc, part) => acc + part.length, 0);
    finalScoreDisplay.textContent = `${totalScore} / ${totalQuestions}`;

    const endTime = new Date();
    const durationSeconds = Math.floor((endTime - examStartTime) / 1000);

    // Send to backend
    fetch('/api/submit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: studentName,
        score: totalScore,
        timeTaken: durationSeconds,
        submittedAt: endTime.toISOString()
      })
    }).then(() => console.log('Result saved')).catch(err => console.error('Save failed', err));
  }

  // --- INIT APP ---
  init();
});
