const express = require('express');
const path = require('path');
const fs = require('fs');

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));

// Load data
let users = require('./users.json');
let questions = require('./questions.js'); // ✅ corrected extension

const scoresPath = path.join(__dirname, 'scores.json');

// -------------------- LOGIN --------------------
app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  const user = users.find(u => u.username === username && u.password === password);

  if (!user) {
    return res.json({ success: false, message: 'Invalid credentials' });
  }

  let hasTakenExam = false;
  if (user.role === 'student' && fs.existsSync(scoresPath)) {
    const scores = JSON.parse(fs.readFileSync(scoresPath, 'utf-8'));
    hasTakenExam = scores.some(entry => entry.username === username);
  }

  res.json({ success: true, username: user.username, role: user.role, hasTakenExam });
});

// -------------------- GET QUESTIONS --------------------
app.get('/api/questions', (req, res) => {
  res.json(questions);
});

// -------------------- START EXAM (Camera Check) --------------------
app.post('/api/start-exam', (req, res) => {
  const { username, camVerified } = req.body;

  if (!camVerified) {
    return res.status(403).json({ message: 'Camera must be ON to start the exam' });
  }

  if (fs.existsSync(scoresPath)) {
    const scores = JSON.parse(fs.readFileSync(scoresPath, 'utf-8'));
    const alreadyDone = scores.find(entry => entry.username === username);
    if (alreadyDone) {
      return res.status(403).json({ message: 'You have already completed the exam.' });
    }
  }

  res.json({ message: 'Exam started', questions });
});

// -------------------- SUBMIT EXAM --------------------
app.post('/api/submit-exam', (req, res) => {
  const { username, answers, startTime, endTime } = req.body;

  if (!username || !answers || !startTime || !endTime) {
    return res.status(400).json({ message: 'Missing exam data' });
  }

  let scores = [];
  if (fs.existsSync(scoresPath)) {
    scores = JSON.parse(fs.readFileSync(scoresPath, 'utf-8'));
    if (scores.find(entry => entry.username === username)) {
      return res.status(409).json({ message: 'Exam already submitted.' });
    }
  }

  let correct = 0;
  questions.forEach((q, i) => {
    if (q.answer === answers[i]) correct++;
  });

  const newEntry = {
    username,
    score: correct,
    total: questions.length,
    startTime,
    endTime,
    status: 'Completed'
  };

  scores.push(newEntry);
  fs.writeFileSync(scoresPath, JSON.stringify(scores, null, 2));

  res.json({ message: 'Exam submitted successfully', score: correct });
});

// -------------------- ADMIN RESULTS --------------------
app.get('/api/admin/results', (req, res) => {
  if (!fs.existsSync(scoresPath)) {
    return res.json([]);
  }

  const scores = JSON.parse(fs.readFileSync(scoresPath, 'utf-8'));
  res.json(scores);
});

// -------------------- FALLBACK --------------------
app.get('/*', (req, res) => {
  res.sendFile(path.join(__dirname, '../public', 'index.html'));
});

// -------------------- START SERVER --------------------
app.listen(3000, () => {
  console.log(`✅ Server running on http://localhost:3000`);
});
